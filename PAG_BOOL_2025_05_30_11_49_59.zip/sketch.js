let player;
let fallingObjects = [];
let score = 0;

function setup() {
  createCanvas(400, 400);
  player = new Player();
}

function draw() {
  background(220);
  
  // Atualiza e desenha objetos que caem
  if (frameCount % 60 === 0) {
    fallingObjects.push(new FallingObject());
  }
  
  for (let i = fallingObjects.length - 1; i >= 0; i--) {
    fallingObjects[i].update();
    fallingObjects[i].show();
    
    // Verifica se o objeto foi pegado
    if (fallingObjects[i].hits(player)) {
      score++;
      fallingObjects.splice(i, 1);
    }
    
    // Remove objetos que saíram da tela
    if (fallingObjects[i].offScreen()) {
      fallingObjects.splice(i, 1);
    }
  }
  
  player.show();
  player.move();
  
  // Exibe a pontuação
  textSize(32);
  fill(0);
  text(`Score: ${score}`, 10, 30);
}

class Player {
  constructor() {
    this.width = 60;
    this.height = 10;
    this.x = width / 2 - this.width / 2;
  }
  
  move() {
    if (keyIsDown(LEFT_ARROW)) {
      this.x -= 5;
    }
    if (keyIsDown(RIGHT_ARROW)) {
      this.x += 5;
    }
    this.x = constrain(this.x, 0, width - this.width);
  }
  
  show() {
    fill(0);
    rect(this.x, height - this.height, this.width, this.height);
  }
}

class FallingObject {
  constructor() {
    this.x = random(width);
    this.y = 0;
    this.size = 20;
    this.speed = 3;
  }
  
  update() {
    this.y += this.speed;
  }
  
  show() {
    fill(255, 0, 0);
    ellipse(this.x, this.y, this.size);
  }
  
  hits(player) {
    return (this.x > player.x && this.x < player.x + player.width && this.y + this.size / 2 > height - player.height);
  }
  
  offScreen() {
    return this.y > height;
  }
}
